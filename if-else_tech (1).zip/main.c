/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

void main()
{
    float a=12.25,b=13.65;
    if(a=  b)
    printf("a and b both are equal");
    else
    printf("a and b both are not equal")
    return 0;
}
